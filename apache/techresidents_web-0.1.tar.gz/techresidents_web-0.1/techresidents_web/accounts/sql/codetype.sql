INSERT INTO accounts_codetype (type, description) VALUES ('REGISTRATION', 'Registration code');
INSERT INTO accounts_codetype (type, description) VALUES ('RESET_PASSWORD', 'Reset password code');
