INSERT INTO chat_role (role, description) VALUES ('DEFAULT', 'Default Chat Role');
INSERT INTO chat_role (role, description) VALUES ('MODERATOR', 'Moderator Chat Role');
