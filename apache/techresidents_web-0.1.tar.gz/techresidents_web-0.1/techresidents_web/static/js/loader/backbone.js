define([
    'Loader'
], function(Loader) {
    return Loader.Backbone;
});
