define([
    'Loader'
], function(Loader) {
});
