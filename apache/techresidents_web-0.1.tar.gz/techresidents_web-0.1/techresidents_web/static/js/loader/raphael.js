define([
    'order!3ps/raphael/raphael'
], function() {
    var Raphael = window.Raphael;
    window.Raphael = null;
    return Raphael;
});
