define([
    'Loader'
], function(Loader) {
    return Loader._;
});
