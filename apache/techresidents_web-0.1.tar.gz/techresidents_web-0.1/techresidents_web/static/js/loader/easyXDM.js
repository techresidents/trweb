define([
    '3ps/easyXDM/easyXDM'
], function() {
    return easyXDM.noConflict();
});
