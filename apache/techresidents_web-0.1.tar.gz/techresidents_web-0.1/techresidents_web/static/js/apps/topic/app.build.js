({
        appDir: ".",
        baseUrl: "../../",
        dir: "../../../../static_collected/js/apps/topic",
        modules: [
                { name: "apps/topic/main" }
        ],
   paths: {
        Loader: 'loader/loader-min',
        jQuery: 'loader/jquery',
        Underscore: 'loader/underscore',
        Backbone: 'loader/backbone',
        Highcharts: 'loader/highcharts',
    }
})

