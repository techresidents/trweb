INSERT INTO topic_style (style, description) VALUES ('DEFAULT', 'Default topic style');
